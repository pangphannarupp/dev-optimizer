/** A sample TS class */
export class TestClass {
  prop: string = 'val';
  method() {}
}
