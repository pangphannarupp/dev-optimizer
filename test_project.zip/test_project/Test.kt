/** A sample Kotlin class */
class TestKotlin {
  val x = 1
  fun action() {}
}
